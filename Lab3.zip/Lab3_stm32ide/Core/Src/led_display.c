#include "main.h"
#include "led_display.h"
#include "input_processing.h"

/* =====================================================
   FOUR-DIGIT SEVEN SEGMENT DISPLAY
   PA8  : Digit 1 - Road 1 tens
   PA9  : Digit 2 - Road 1 units
   PA10 : Digit 3 - Road 2 tens
   PA11 : Digit 4 - Road 2 units

   Segment pins: PB0, PB1, PB2, PB4, PB5, PB6, PB7
   Active LOW
   ===================================================== */

static uint8_t scan_digit = 0U;
static uint32_t last_scan_tick = 0U;
static uint32_t last_led_tick = 0U;
static uint8_t led_state = 0U;

static uint8_t digit_buffer[4] = {0U, 0U, 0U, 0U};

static const uint16_t digit_pins[4] =
{
    GPIO_PIN_8,
    GPIO_PIN_9,
    GPIO_PIN_10,
    GPIO_PIN_11
};

/* =====================================================
   TRAFFIC LIGHT CONFIGURATION
   ===================================================== */

static uint8_t traffic_phase = 0U;
static uint8_t traffic_initialized = 0U;

static uint32_t phase_start_tick = 0U;

static uint8_t last_displayed_phase = 255U;
static uint8_t last_mode = 0U;

static uint8_t blink_state = 1U;
static uint32_t last_blink_tick = 0U;

/* =====================================================
   SEVEN SEGMENT FUNCTIONS
   ===================================================== */

static void all_digits_off(void)
{
    HAL_GPIO_WritePin(GPIOA,
        GPIO_PIN_8 | GPIO_PIN_9 |
        GPIO_PIN_10 | GPIO_PIN_11,
        GPIO_PIN_SET);
}

static void all_segments_off(void)
{
    HAL_GPIO_WritePin(GPIOB,
        GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 |
        GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 |
        GPIO_PIN_7,
        GPIO_PIN_SET);
}

static void display_digit(uint8_t number)
{
    static const uint8_t patterns[10] =
    {
        0x3F, 0x06, 0x5B, 0x4F, 0x66,
        0x6D, 0x7D, 0x07, 0x7F, 0x6F
    };

    uint8_t pattern = 0U;

    if (number <= 9U)
    {
        pattern = patterns[number];
    }

    HAL_GPIO_WritePin(a_GPIO_Port, a_Pin,
        (pattern & 0x01U) ? GPIO_PIN_RESET : GPIO_PIN_SET);

    HAL_GPIO_WritePin(b_GPIO_Port, b_Pin,
        (pattern & 0x02U) ? GPIO_PIN_RESET : GPIO_PIN_SET);

    HAL_GPIO_WritePin(c_GPIO_Port, c_Pin,
        (pattern & 0x04U) ? GPIO_PIN_RESET : GPIO_PIN_SET);

    HAL_GPIO_WritePin(d_GPIO_Port, d_Pin,
        (pattern & 0x08U) ? GPIO_PIN_RESET : GPIO_PIN_SET);

    HAL_GPIO_WritePin(e_GPIO_Port, e_Pin,
        (pattern & 0x10U) ? GPIO_PIN_RESET : GPIO_PIN_SET);

    HAL_GPIO_WritePin(f_GPIO_Port, f_Pin,
        (pattern & 0x20U) ? GPIO_PIN_RESET : GPIO_PIN_SET);

    HAL_GPIO_WritePin(g_GPIO_Port, g_Pin,
        (pattern & 0x40U) ? GPIO_PIN_RESET : GPIO_PIN_SET);
}

static void refresh_7seg(void)
{
    uint32_t now = HAL_GetTick();

    /* Scan one digit every 2 ms */
    if ((uint32_t)(now - last_scan_tick) < 50U)
    {
        return;
    }

    last_scan_tick = now;

    all_digits_off();
    all_segments_off();

    display_digit(digit_buffer[scan_digit]);

    HAL_GPIO_WritePin(GPIOA,
        digit_pins[scan_digit],
        GPIO_PIN_RESET);

    scan_digit++;

    if (scan_digit >= 4U)
    {
        scan_digit = 0U;
    }
}

/* =====================================================
   TRAFFIC LIGHT FUNCTIONS
   PA0: Road 1 RED
   PA1: Road 1 AMBER
   PA2: Road 1 GREEN
   PA3: Road 2 RED
   PA4: Road 2 AMBER
   PA5: Road 2 GREEN

   Each GPIO controls two physical LEDs.
   Active LOW
   ===================================================== */

static void all_traffic_lights_off(void)
{
    HAL_GPIO_WritePin(GPIOA,
        RED1_Pin | YELLOW1_Pin | GREEN1_Pin |
        RED2_Pin | YELLOW2_Pin | GREEN2_Pin,
        GPIO_PIN_SET);
}

static void set_traffic_lights(uint8_t phase)
{
    all_traffic_lights_off();

    switch (phase)
    {
        case 0U:
            /* Road 1 RED, Road 2 GREEN */
            HAL_GPIO_WritePin(GPIOA,
                RED1_Pin | GREEN2_Pin,
                GPIO_PIN_RESET);
            break;

        case 1U:
            /* Road 1 RED, Road 2 AMBER */
            HAL_GPIO_WritePin(GPIOA,
                RED1_Pin | YELLOW2_Pin,
                GPIO_PIN_RESET);
            break;

        case 2U:
            /* Road 1 GREEN, Road 2 RED */
            HAL_GPIO_WritePin(GPIOA,
                GREEN1_Pin | RED2_Pin,
                GPIO_PIN_RESET);
            break;

        case 3U:
            /* Road 1 AMBER, Road 2 RED */
            HAL_GPIO_WritePin(GPIOA,
                YELLOW1_Pin | RED2_Pin,
                GPIO_PIN_RESET);
            break;

        default:
            all_traffic_lights_off();
            break;
    }
}

/* =====================================================
   PHASE DURATION
   ===================================================== */

static uint32_t get_phase_duration(uint8_t phase)
{
    switch (phase)
    {
        case 0U:
        case 2U:
            return (uint32_t)green_time * 1000U;

        case 1U:
        case 3U:
            return (uint32_t)amber_time * 1000U;

        default:
            return 50U;
    }
}

/* Convert remaining milliseconds to displayed seconds */
static uint8_t remaining_seconds(uint32_t total_ms,
                                 uint32_t elapsed_ms)
{
    uint32_t remaining_ms;

    if (elapsed_ms >= total_ms)
    {
        return 0U;
    }

    remaining_ms = total_ms - elapsed_ms;

    return (uint8_t)((remaining_ms + 999U) / 1000U);
}

/* =====================================================
   UPDATE TRAFFIC PHASE AND BOTH COUNTDOWNS
   ===================================================== */
static void update_led_PA14(void)
{
    uint32_t now = HAL_GetTick();

    if ((uint32_t)(now - last_led_tick) >= 250U)
    {
        last_led_tick = now;
        led_state ^= 1U;

        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_14,
            led_state ? GPIO_PIN_SET : GPIO_PIN_RESET);
    }
}

static void update_countdown(void)
{
    uint32_t now = HAL_GetTick();

    uint32_t duration;
    uint32_t elapsed;

    uint8_t road1_countdown;
    uint8_t road2_countdown;

    duration = get_phase_duration(traffic_phase);
    elapsed = now - phase_start_tick;

    while (elapsed >= duration)
    {
        phase_start_tick += duration;

        traffic_phase++;

        if (traffic_phase >= 4U)
        {
            traffic_phase = 0U;
        }

        duration = get_phase_duration(traffic_phase);
        elapsed = now - phase_start_tick;
    }

    if (last_displayed_phase != traffic_phase)
    {
        set_traffic_lights(traffic_phase);
        last_displayed_phase = traffic_phase;
    }

    switch (traffic_phase)
    {
        case 0U:
            /*
             * Road 1: RED
             * Road 2: GREEN
             */
            road1_countdown = remaining_seconds(
                (uint32_t)red_time * 1000U,
                elapsed);

            road2_countdown = remaining_seconds(
                (uint32_t)green_time * 1000U,
                elapsed);
            break;

        case 1U:
            /*
             * Road 1: RED
             * Road 2: AMBER
             */
            road1_countdown = remaining_seconds(
                (uint32_t)amber_time * 1000U,
                elapsed);

            road2_countdown = road1_countdown;
            break;

        case 2U:
            /*
             * Road 1: GREEN
             * Road 2: RED
             */
            road1_countdown = remaining_seconds(
                (uint32_t)green_time * 1000U,
                elapsed);

            road2_countdown = remaining_seconds(
                (uint32_t)red_time * 1000U,
                elapsed);
            break;

        case 3U:
            /*
             * Road 1: AMBER
             * Road 2: RED
             */
            road1_countdown = remaining_seconds(
                (uint32_t)amber_time * 1000U,
                elapsed);

            road2_countdown = road1_countdown;
            break;

        default:
            road1_countdown = 0U;
            road2_countdown = 0U;
            break;
    }

    /* Road 1: PA8 and PA9 */
    digit_buffer[0] = road1_countdown / 10U;
    digit_buffer[1] = road1_countdown % 10U;

    /* Road 2: PA10 and PA11 */
    digit_buffer[2] = road2_countdown / 10U;
    digit_buffer[3] = road2_countdown % 10U;
}

/* =====================================================
   BLINK SELECTED TRAFFIC LIGHT COLOR
   2 Hz: toggle every 250 ms
   ===================================================== */

static uint32_t blink_timer = 0U;
static uint8_t blink_mode = 0U;

static void update_blink_mode(uint8_t mode)
{
    uint32_t now = HAL_GetTick();

    if (mode != blink_mode)
    {
        blink_mode = mode;
        blink_timer = now;
        blink_state = 1U;
    }

    if ((uint32_t)(now - blink_timer) >= 4000U)
    {
        blink_timer = now;
        blink_state ^= 1U;
    }

    all_traffic_lights_off();

    if (blink_state == 0U)
        return;

    switch (mode)
    {
        case 2U:
            HAL_GPIO_WritePin(GPIOA,
                RED1_Pin | RED2_Pin, GPIO_PIN_RESET);
            break;

        case 3U:
            HAL_GPIO_WritePin(GPIOA,
                YELLOW1_Pin | YELLOW2_Pin, GPIO_PIN_RESET);
            break;

        case 4U:
            HAL_GPIO_WritePin(GPIOA,
                GREEN1_Pin | GREEN2_Pin, GPIO_PIN_RESET);
            break;
    }
}


static void update_mode_display(uint8_t mode)
{
    uint8_t value = temp_val;

    /* PA8 and PA9: selected value */
    digit_buffer[0] = value / 10U;
    digit_buffer[1] = value % 10U;

    /* PA10 and PA11: mode number */
    digit_buffer[2] = 0U;
    digit_buffer[3] = mode;
}


static void traffic_light_init(void)
{
    if (traffic_initialized != 0U)
    {
        return;
    }

    traffic_initialized = 1U;

    traffic_phase = 0U;
    phase_start_tick = HAL_GetTick();

    all_traffic_lights_off();

    set_traffic_lights(traffic_phase);
    last_displayed_phase = traffic_phase;
}

void led_display_update(uint8_t mode)
{
    uint32_t now = HAL_GetTick();

    update_led_PA14();
    traffic_light_init();

    if (mode != last_mode)
    {
        last_mode = mode;

        blink_state = 1U;
        last_blink_tick = now;

        if (mode == 1U)
        {
            traffic_phase = 0U;
            phase_start_tick = now;
            last_displayed_phase = 255U;
        }
    }

    if (mode == 1U)
    {
        update_countdown();
    }
    else
    {
        update_blink_mode(mode);
        update_mode_display(mode);
    }

    refresh_7seg();
}
