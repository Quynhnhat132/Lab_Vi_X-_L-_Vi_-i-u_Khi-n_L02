
#include "main.h"
#include "input_reading.h"
#include "input_processing.h"
#include "led_display.h"

uint8_t current_mode = 1U;

volatile uint8_t red_time = 5U;
volatile uint8_t amber_time = 2U;
volatile uint8_t green_time = 3U;

volatile uint8_t temp_val = 5U;

static uint8_t previous_button_state[3] = {0U, 0U, 0U};

static uint8_t button_pressed_event(uint8_t index)
{
    uint8_t current = is_button_pressed(index);
    uint8_t event = 0U;

    if ((current != 0U) &&
        (previous_button_state[index] == 0U))
    {
        event = 1U;
    }

    previous_button_state[index] = current;

    return event;
}

void fsm_for_input_processing(void)
{
    /* BUTTON 1: Change mode */
	if (button_pressed_event(0U))
	{
	    if (current_mode >= 4U)
	    {
	        current_mode = 1U;
	    }
	    else
	    {
	        current_mode++;
	    }

	    switch (current_mode)
	    {
	        case 1U:
	            temp_val = red_time;
	            break;

	        case 2U:
	            temp_val = red_time;
	            break;

	        case 3U:
	            temp_val = amber_time;
	            break;

	        case 4U:
	            temp_val = green_time;
	            break;

	        default:
	            current_mode = 1U;
	            break;
	    }
	}

    /* BUTTON 2: Increase temporary value */
    if (button_pressed_event(1U))
    {
        if (current_mode >= 2U && current_mode <= 4U)
        {
            if (temp_val < 99U)
            {
                temp_val++;
            }
        }
    }

    /* BUTTON 3: Confirm and save */
    if (button_pressed_event(2U))
    {
        switch (current_mode)
        {
            case 2U:
                /* Modify RED and automatically update GREEN */
                if ((temp_val > amber_time) && (temp_val <= 99U))
                {
                    red_time = temp_val;
                    green_time = red_time - amber_time;
                }
                break;

            case 3U:
                /* Modify AMBER and automatically update RED */
                if ((temp_val >= 1U) &&
                    ((uint16_t)green_time + temp_val <= 99U))
                {
                    amber_time = temp_val;
                    red_time = green_time + amber_time;
                }
                break;

            case 4U:
                /* Modify GREEN and automatically update RED */
                if ((temp_val >= 1U) &&
                    ((uint16_t)amber_time + temp_val <= 99U))
                {
                    green_time = temp_val;
                    red_time = green_time + amber_time;
                }
                break;

            default:
                break;
        }
    }

    /* Update display and traffic light */
    led_display_update(current_mode);
}
