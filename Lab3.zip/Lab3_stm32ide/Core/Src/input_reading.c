#include "input_reading.h"
#include "main.h"

#define N0_OF_BUTTONS 3


#define BUTTON_IS_PRESSED GPIO_PIN_RESET
#define BUTTON_IS_RELEASED GPIO_PIN_SET

#define LONG_PRESS_TIME 1000U

static GPIO_TypeDef *buttonPorts[N0_OF_BUTTONS] =
{
    BUTTON_1_GPIO_Port,
    BUTTON_2_GPIO_Port,
    BUTTON_3_GPIO_Port
};

static const uint16_t buttonPins[N0_OF_BUTTONS] =
{
    BUTTON_1_Pin,
    BUTTON_2_Pin,
    BUTTON_3_Pin
};

static GPIO_PinState buttonBuffer[N0_OF_BUTTONS] =
{
    BUTTON_IS_RELEASED,
    BUTTON_IS_RELEASED,
    BUTTON_IS_RELEASED
};

static GPIO_PinState debounceBuffer1[N0_OF_BUTTONS] =
{
    BUTTON_IS_RELEASED,
    BUTTON_IS_RELEASED,
    BUTTON_IS_RELEASED
};

static GPIO_PinState debounceBuffer2[N0_OF_BUTTONS] =
{
    BUTTON_IS_RELEASED,
    BUTTON_IS_RELEASED,
    BUTTON_IS_RELEASED
};

static uint16_t pressCounter[N0_OF_BUTTONS] = {0};
static uint8_t longPressFlag[N0_OF_BUTTONS] = {0};

void button_reading(void)
{
    for (uint8_t i = 0; i < N0_OF_BUTTONS; i++)
    {
        debounceBuffer2[i] = debounceBuffer1[i];

        debounceBuffer1[i] =
            HAL_GPIO_ReadPin(buttonPorts[i], buttonPins[i]);

        if (debounceBuffer1[i] == debounceBuffer2[i])
        {
            buttonBuffer[i] = debounceBuffer1[i];
        }

        if (buttonBuffer[i] == BUTTON_IS_PRESSED)
        {
            if (pressCounter[i] < LONG_PRESS_TIME)
            {
                pressCounter[i] += TIMER_INTERRUPT_DURATION;

                if (pressCounter[i] > LONG_PRESS_TIME)
                {
                    pressCounter[i] = LONG_PRESS_TIME;
                }
            }

            if (pressCounter[i] >= LONG_PRESS_TIME)
            {
                longPressFlag[i] = 1;
            }
        }
        else
        {
            pressCounter[i] = 0;
            longPressFlag[i] = 0;
        }
    }
}

unsigned char is_button_pressed(uint8_t index)
{
    if (index >= N0_OF_BUTTONS)
        return 0;

    return (buttonBuffer[index] == BUTTON_IS_PRESSED);
}

unsigned char is_button_pressed_1s(unsigned char index)
{
    if (index >= N0_OF_BUTTONS)
        return 0;

    return longPressFlag[index];
}
