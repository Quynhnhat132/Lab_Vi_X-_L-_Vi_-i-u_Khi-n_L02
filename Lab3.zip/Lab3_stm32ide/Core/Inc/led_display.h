#ifndef LED_DISPLAY_H
#define LED_DISPLAY_H

#include "main.h"

void led_display_update(uint8_t mode);

#endif
