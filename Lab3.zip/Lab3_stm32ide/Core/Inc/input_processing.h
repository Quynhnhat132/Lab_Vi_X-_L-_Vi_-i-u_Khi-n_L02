
#ifndef INPUT_PROCESSING_H
#define INPUT_PROCESSING_H

#include "main.h"

extern uint8_t current_mode;

extern volatile uint8_t red_time;
extern volatile uint8_t amber_time;
extern volatile uint8_t green_time;
extern volatile uint8_t temp_val;

void fsm_for_input_processing(void);

#endif
