#ifndef INPUT_READING_H
#define INPUT_READING_H

#include "main.h"

void button_reading(void);

unsigned char is_button_pressed(unsigned char index);

unsigned char is_button_pressed_1s(unsigned char index);

#endif /* INC_INPUT_READING_H_ */
